package com.juslin.web;

import java.util.ArrayList;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.juslin.domain.Student;

@Controller
public class HelloController {
	/*
	@RequestMapping("/index")
	public String index() {
		return "Tämä on pääsivu";
	}
	@RequestMapping("/contact")
	public String contact() {
		return "Otamme teihin yhteyttä mahdollisimman pian";
	}
	*/
	@RequestMapping("/hello")
	public String hello(Model model) {
		Student student1 = new Student("Jukka", "Juslin", "juslin@gmail.com");
		Student student2 = new Student("Mark", "Green", "green@gmail.com");
		Student student3 = new Student("Sue", "Gibbons", "sue@gmail.com");
		ArrayList<Student> students = new ArrayList<Student>();
		students.add(student1);
		students.add(student2);
		students.add(student3);
		
		model.addAttribute("students", students);
		return "index";
	}
}
