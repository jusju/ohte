package com.juslin.ohte.controller;

import java.util.ArrayList;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.juslin.ohte.domain.Student;

@Controller
public class HelloController {

	private ArrayList<String> friends = new ArrayList<String>();

	@RequestMapping(value="/index", method=RequestMethod.GET)
	public String friendSubmit(@RequestParam(value="name") String name, Model model) {
		friends.add(name);
		model.addAttribute("friends", friends);
		model.addAttribute("name", name);
		return "index";
	}
	
}
